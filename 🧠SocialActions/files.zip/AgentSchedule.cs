// AgentSchedule.cs
using System.Collections.Generic;
using UnityEngine;

public class AgentSchedule
{
    private Agent agent;

    public AgentSchedule(Agent agent)
    {
        this.agent = agent;
    }

    public void RunSchedules()
    {
        // ✅ Social actions (combat, vampire bites, bar fights, etc.) get first
        // priority. Selection/targeting/movement/cooldowns now live entirely
        // in ActionManager — see Agent.Actions.
        agent.Actions.UpdateActions();

        // If the agent currently has an active social-action plan, pause
        // shopping and leaving-town decisions until it resolves. Sleeping
        // will slot into this same priority check once that system exists.
        if (agent.Actions.HasActivePlan)
            return;

        UpdateSpendSchedule();
        UpdateLeaveSchedule();
    }

    public void UpdateSpendSchedule()
    {
        if (agent.isDead || agent.isOnSpendTrip || agent.isLeavingTown)
            return;

        float tickLength = agent.GetGameTickLength();
        if (tickLength <= 0f)
            tickLength = 1f;

        agent.spendTickAccumulator += Time.deltaTime;

        while (agent.spendTickAccumulator >= tickLength)
        {
            agent.spendTickAccumulator -= tickLength;
            agent.Spending.DecideWhereToSpend();

            if (agent.isOnSpendTrip)
                break;
        }
    }

    public void UpdateLeaveSchedule()
    {
        if (agent.isDead || !agent.outsider || agent.isLeavingTown)
            return;

        float halfTickLength = agent.GetGameTickLength() * 0.5f;
        if (halfTickLength <= 0f)
            halfTickLength = 0.5f;

        agent.leaveTickAccumulator += Time.deltaTime;

        while (agent.leaveTickAccumulator >= halfTickLength)
        {
            agent.leaveTickAccumulator -= halfTickLength;
            AgentLeaving.DecideWhetherToLeave(agent);
        }
    }
}
