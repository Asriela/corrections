// AgentTeams.cs
using System.Collections.Generic;

public static class AgentTeams
{
    public static Dictionary<TeamType, List<Agent>> TeamMembers = new();

    public static void RegisterTeamMember(Agent agent, TeamType team)
    {
        if (agent == null || team == TeamType.none)
            return;

        DeregisterTeamMember(agent);

        if (!TeamMembers.TryGetValue(team, out List<Agent> members) || members == null)
        {
            members = new List<Agent>();
            TeamMembers[team] = members;
        }

        if (!members.Contains(agent))
            members.Add(agent);
    }

    public static void DeregisterTeamMember(Agent agent)
    {
        if (agent == null)
            return;

        foreach (var pair in TeamMembers)
        {
            if (pair.Value == null)
                continue;

            pair.Value.Remove(agent);
        }
    }
}
