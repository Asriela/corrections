// AgentPlacement.cs
using System.Collections.Generic;
using UnityEngine;

public static class AgentPlacement
{
    public static void MoveAgentIntoBuilding(Agent agent, Vector2Int tile, bool roamInside)
    {
        if (agent == null)
            return;

        agent.movementType = MovementType.AllowTargetBuildingOnly;
        agent.targetTile = tile;

        Vector3 world = AgentPathing.GridToWorld(agent, tile);
        AgentMovement.SetPath(agent, new List<Vector3> { world });

        // SetPath resets roamInsideTarget as a safety default — re-apply after.
        // This is a permanent placement (e.g. a pen animal): it roams here
        // forever, until something else (death, re-homing) explicitly moves it.
        agent.roamInsideTarget = roamInside;

        // tells Agent.Start()/SetRole() not to overwrite this placement
        agent.hasExplicitPlacement = true;
    }
}
