using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

[System.Serializable]
public enum AgentType
{
    none,
    jobSeeker,
    farmer,
    lawman,
    miner,
    prostitute,
    railwayMan,
    military,
    gangMember,
    entertainer,
    doctor,
    preacher,
    trader,
    vagrant,
    oilMan,
    hostileTroop,
    diseased,
    nativeAmerican,
    ghost,
    artisan,
    casinoHost,
    banker,
    gambler,
    furTrader,
    foodTrader,
    nightWatcher,
    pig,
    cayote
}

public enum TeamType
{
    none,
    townDefenders,
    gang,
    hostileTroops
}

#region TAG SYSTEM ✅

public enum AgentTag
{
    None,

    Prey,
    Predator,

    Civilian,
    Enemy,
    Ally,

    Animal,
    Human,
    Undead,
 
}

#endregion

#region STATS & SPENDING

[System.Serializable]
public class PointStat
{
    public scoreType typeOfScore;
    public float amount;
}

[System.Serializable]
public class BuyStat
{
    public AgentType who;
    public float amount;
}

[System.Serializable]
public class BuyBehaviour
{
    public BuildingType where;
    public int chance;
    public float amount;
}

#endregion

// =====================================================
// 🤝 INTERACTION SYSTEM
// =====================================================
#region INTERACTION SYSTEM
public enum InteractionType
{
    Combat,
    VampireBite,
    // ✅ NEW: added for BarFightAction / HarvestAnimalAction in SocialActions.cs
    BarFight,
    Swoon,
    Heal,
    Convert,
    FleeFrom,
    HarvestAnimal
}

[System.Serializable]
public class AgentInteraction
{
    [Tooltip("Targets any agent that has ANY of these tags")]
    public List<AgentTag> targetTags;

    public InteractionType type;

    public int priority = 0;

    public float chance = 1f;
    public float range = 1f;

    public float cooldown = 1f;
    public float value = 0f;

    // ⚠️ ADDED: ActionManager.MoveTowardTarget reads this to decide between
    // open-field stand-off positioning vs. pathfinding onto the target's
    // building tile (e.g. attacking a penned animal). It was referenced by
    // the old AgentActions.cs but wasn't defined here — if it already exists
    // elsewhere in the project, remove this duplicate.
    [Header("Movement")]
    [Tooltip("If true, this interaction is allowed to path onto the target's building tile (e.g. a pig in its pen). If false, uses open-field stand-off positioning.")]
    public bool canEnterTargetBuilding = false;

    // Combat-specific positioning (used when type == Combat)
    [Header("Combat Positioning - for full fidelity")]
    public float alignmentTolerance = 0.20f;
    public float standOffDistance = 1.0f;
}

#endregion

[CreateAssetMenu(fileName = "NewAgent", menuName = "NewAgent")]
public class ScriptableAgent : ScriptableObject
{
    [Header("Basic Agent Info")]
    public AgentType type;
    public Color debugColor;
    public TeamType team = TeamType.none;

    [Header("Agent Stats")]
    [SerializeField] public List<PointStat> stats;

    [Header("Tags ✅")]
    [SerializeField] public List<AgentTag> tags;

    [Header("Spending")]
    [SerializeField] public List<BuyBehaviour> spendsAt;

    [Header("Hangout Preferences")]
    [SerializeField] public List<BuildingType> hangsAround;

    [Header("Interactions (Agent ↔ Agent)")]
    [SerializeField] public List<AgentInteraction> interactions;
}
