// SocialActions.cs
using System.Collections.Generic;
using UnityEngine;

// =====================================================
// 🤝 SOCIAL ACTIONS
// Each action owns only its unique effect — ActionManager has
// already handled selection, targeting, movement, alignment,
// range, and cooldowns by the time Execute() is called here.
// =====================================================

public interface ISocialAction
{
    void Execute(Agent self, Agent target, AgentInteraction interaction);
}

public class CombatAction : ISocialAction
{
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        float damage = Mathf.Max(1f, interaction.value > 0f ? interaction.value : 10f);
        AgentDeath.HurtAgent(target, deathType.bleeding, damage);

        // fright check happens regardless of how much damage was actually dealt
        AgentFear.TryTriggerFright(target, self);
    }
}

public class VampireBiteAction : ISocialAction
{
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        float damage = Mathf.Max(1f, interaction.value);
        AgentDeath.HurtAgent(target, deathType.bleeding, damage);
        self.health = Mathf.Min(100f, self.health + damage * 0.5f);

        // same fright check as combat — this also deals damage
        AgentFear.TryTriggerFright(target, self);
    }
}

public class BarFightAction : ISocialAction
{
    // 🚧 PLACEHOLDER — BarFight wasn't part of the original InteractionType
    // enum; added because the new structure calls for it. Modeled loosely on
    // Combat: lower damage, no fright trigger (a saloon scuffle shouldn't send
    // half the town running home scared). Swap in real bar-fight rules —
    // multi-participant brawl, knockback, drink-spill effects — once designed.
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        float damage = Mathf.Max(1f, interaction.value > 0f ? interaction.value : 3f);
        AgentDeath.HurtAgent(target, deathType.bleeding, damage);
    }
}

public class HealAction : ISocialAction
{
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        target.health = Mathf.Min(100f, target.health + interaction.value);
    }
}

public class SwoonAction : ISocialAction
{
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        target.waitTimer = Mathf.Max(target.waitTimer, interaction.value);
    }
}

public class ConvertAction : ISocialAction
{
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        Debug.Log($"Convert attempted on {target.type}");
    }
}

public class FleeAction : ISocialAction
{
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        // "target" here is the threat self is fleeing from
        Vector3 fleeDir = (self.transform.position - target.transform.position).normalized;
        Vector3 fleeTarget = self.transform.position + fleeDir * 3f;

        AgentMovement.SetPath(self, new List<Vector3> { fleeTarget });
    }
}

public class HarvestAnimalAction : ISocialAction
{
    // 🚧 PLACEHOLDER — no harvest/resource-yield rules exist yet in the
    // codebase (no stat hookup was specified for animal products). Currently
    // just kills the target and logs it. Wire this up to whatever resource
    // system pigs/foxes should feed — food stat, gold, a dedicated hide/meat stat.
    public void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        AgentDeath.HurtAgent(target, deathType.bleeding, 9999f);
        Debug.Log($"{self.type} harvested {target.type}");
    }
}

// =====================================================
// 🗂️ DISPATCHER
// =====================================================
public static class SocialActions
{
    private static readonly Dictionary<InteractionType, ISocialAction> registry = new()
    {
        { InteractionType.Combat, new CombatAction() },
        { InteractionType.VampireBite, new VampireBiteAction() },
        { InteractionType.BarFight, new BarFightAction() },
        { InteractionType.Heal, new HealAction() },
        { InteractionType.Swoon, new SwoonAction() },
        { InteractionType.Convert, new ConvertAction() },
        { InteractionType.FleeFrom, new FleeAction() },
        { InteractionType.HarvestAnimal, new HarvestAnimalAction() },
    };

    public static void Execute(Agent self, Agent target, AgentInteraction interaction)
    {
        if (self == null || target == null || target.isDead)
            return;

        self.Visuals.TriggerAttackVisual();

        if (registry.TryGetValue(interaction.type, out var action))
        {
            action.Execute(self, target, interaction);
        }
        else
        {
            Debug.LogWarning($"SocialActions: no action registered for {interaction.type}");
        }
    }
}
