// AgentTrading.cs
public static class AgentTrading
{
    private const float FoodTraderGoldCost = 5f;
    private const float FoodTraderFoodGain = 5f;

    public static void HandleClick(Agent agent)
    {
        if (agent == null)
            return;

        if (agent.type == AgentType.foodTrader)
            TradeFoodWithFoodTrader(agent);
    }

    public static bool TradeFoodWithFoodTrader(Agent agent)
    {
        if (agent == null || agent.type != AgentType.foodTrader)
            return false;

        if (StatsCounter.Instance == null || StatsCounter.Instance.StatResults == null)
            return false;

        float currentGold = StatsCounter.Instance.StatResults[stat.tot_Wealth];

        if (currentGold < FoodTraderGoldCost)
        {
            TownStateUI.Instance?.PushTownMessage("Not enough gold.");
            return false;
        }

        StatsCounter.Instance.StatResults[stat.tot_Wealth] -= FoodTraderGoldCost;
        StatsCounter.Instance.StatResults[stat.tot_food] += FoodTraderFoodGain;

        agent.Spending.MakeMoneySpentBubble(-FoodTraderGoldCost, "$");

        return true;
    }
}
