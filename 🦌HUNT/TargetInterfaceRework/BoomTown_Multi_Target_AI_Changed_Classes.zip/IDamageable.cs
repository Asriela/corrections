public interface IDamageable { void TakeDamage(float amount, deathType cause); }
