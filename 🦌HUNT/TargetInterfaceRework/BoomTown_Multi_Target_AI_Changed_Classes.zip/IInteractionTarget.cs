using UnityEngine;
public interface IInteractionTarget
{
    TargetKind Kind { get; }
    bool Exists { get; }
    Vector3 WorldPosition { get; }
    bool MatchesFilter(AgentInteraction interaction);
    bool TryGetApproach(Agent from, AgentInteraction interaction, out Vector2Int tile, out Vector3 world);
}
