// Agent.cs
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

// ✅ NEW: if this is already declared elsewhere (e.g. your current ScriptableAgent.cs),
// delete this block to avoid a duplicate-definition compile error.
public enum MovementType
{
    AvoidAllBuildings,
    AllowTargetBuildingOnly
}

// Agent.cs — class InventoryItem
[System.Serializable]
public class InventoryItem
{
    public ObjectType type;
    public int amount;

    // true = carried over from someone/something else (harvested). Counts toward
    // carry capacity and is kept as its own stack, separate from the agent's own items.
    public bool isLoot = false;

    public InventoryItem(
        ObjectType type,
        int amount, bool isLoot)
    {
        this.type = type;
        this.amount = amount;
        this.isLoot = isLoot;
    }
}

// Agent.cs — class Agent
public class Agent : MonoBehaviour, IInteractionTarget, IDamageable
{
    [Header("References")]
    public SpriteRenderer spriteRenderer;
    public SpriteRenderer shadowRenderer;
    public BoxCollider2D clickCollider2D;
    public AgentType type;
    public TeamType team = TeamType.none;
    public Dictionary<scoreType, float> AgentStats = new Dictionary<scoreType, float>();
    public Dictionary<AgentType, float> BuysFrom = new Dictionary<AgentType, float>(); // legacy, keep for now
    public Building myHouse = null;
    public bool outsider = false;

    [Header("Visuals")]
    // ⚠️ NOTE: the old `AnimationState animationState` field and its
    // `CurrentAnimationState` property have been removed. Animation is no
    // longer a stored state — it's a pure lookup derived from the current
    // AgentAction, resolved live via agent.Visuals.CurrentAction and
    // AnimationLookup. Nothing in the codebase read this field after the
    // AgentActionState refactor, and the AnimationState enum it depended on
    // no longer exists (AgentAnimations.cs is now string-key based), so
    // keeping it would be a compile error, not just dead code.
    [SerializeField] public float attackVisualDuration = 0.22f;
    [SerializeField] public Color visualTint = Color.white;
    public float attackVisualTimer = 0f;

    [Header("Death")]
    public bool isDead = false;
    public deathType causeOfDeath = deathType.starve;
    public float health = 100f;

    [Header("Movement")]
    [SerializeField] public float moveSpeed = 1.5f;
    [SerializeField] public float arriveDistance = 0.05f;
    [SerializeField] public float pauseBetweenMoves = 0.35f;
    [SerializeField] public float repathDelay = 0.6f;
    [SerializeField] public int maxDestinationAttempts = 40;
    [SerializeField] public float tileEdgePadding = 0.08f;

    // ✅ NEW: movement rules used by AgentPathing / ActionManager for
    // combat approach + "wander near a hangout building" behavior
    [Header("Movement Rules")]
    public MovementType movementType = MovementType.AvoidAllBuildings;
    public Vector2Int targetTile = Vector2Int.zero;
    public bool roamInsideTarget = false;

    // ✅ NEW: small manual nudge for roam center, in case a building's sprite
    // doesn't sit exactly on its logical tile center (e.g. was shifted for
    // visual alignment with neighboring buildings)
    [SerializeField] public float roamCenterYOffset = 0f;

    // ✅ NEW: set by AgentPlacement.MoveAgentIntoBuilding. Prevents Start()/SetRole()
    // from overwriting a deliberate placement (e.g. a pen animal) with normal wandering.
    public bool hasExplicitPlacement = false;

    [Header("Movement Variation")]
    [SerializeField] public float speedVariationStrength = 0.35f;
    [SerializeField] public float speedVariationSpeed = 1.75f;
    [SerializeField] public float acceleration = 6f;
    [SerializeField] public float turnResponsiveness = 8f;

    [Header("Facing")]
    [SerializeField] public float flipThreshold = 0.02f;

    [Header("Interactions")]
    [SerializeField] public float interactionDecisionInterval = 0.75f;

    // ✅ NEW: how much harvested loot this agent can carry at once. Set from
    // ScriptableAgent.carryCapacity in SetRole. Only isLoot items count toward it.
    [Header("Carrying")]
    public int maxCarryCapacity = 10;

    [Header("Debug")]
    [SerializeField] public bool drawPathGizmos = true;
    [SerializeField] public float sortingOffset = 0.1f;

    [Header("Spending Schedule")]
    [SerializeField] public float spendTickAccumulator = 0f;
    internal float budget = 0f;

    [Header("Leaving Schedule")]
    [SerializeField] public float leaveTickAccumulator = 0f;

    [Header("Leaving")]
    [SerializeField] public float desireToLeave = 0f;
    [SerializeField] public float maxLeavePoints = 20f;
    [SerializeField] public float leaveWalkSpeedMultiplier = 1.05f;
    [SerializeField] public float leaveFadeSpeed = 0.75f;

    [Header("Stuck Recovery")]
    [SerializeField] public float stuckRepathTime = 1.25f;

    public readonly List<Vector3> currentPath = new List<Vector3>();
    public int pathIndex = 0;
    public float waitTimer = 0f;

    public float currentSpeed = 0f;
    public float noiseOffset = 0f;

    public Vector3 steeringDirection = Vector3.right;
    public Vector3 steeringVelocity = Vector3.zero;

    public readonly List<BuildingType> preferredBuildingTypes = new List<BuildingType>();
    public readonly List<BuyBehaviour> spendBehaviours = new List<BuyBehaviour>();

    public bool isOnSpendTrip = false;
    public int activeSpendBehaviourIndex = -1;
    public float activeSpendAmount = 0f;

    public bool hasForcedSpendDestination = false;
    public Vector2Int forcedSpendDestinationTile = Vector2Int.zero;

    public bool isLeavingTown = false;
    public bool leaveFadeStarted = false;
    public Vector3 leaveDestinationWorld = Vector3.zero;

    public Vector3 lastFramePosition;
    public float stuckTimer = 0f;
    public float lastDistanceToTarget = -1f;
    public bool hasDistanceSample = false;

    public Color VisualTint => visualTint;

    public bool IsOnSpendTrip => isOnSpendTrip;
    public int SpendBehaviourCount => spendBehaviours.Count;
    public bool HasForcedSpendDestination => hasForcedSpendDestination;
    public Vector2Int ForcedSpendDestinationTile => forcedSpendDestinationTile;
    public List<BuildingType> PreferredBuildingTypes => preferredBuildingTypes;
    public IReadOnlyList<BuyBehaviour> SpendBehaviours => spendBehaviours;
    public float RepathDelay => repathDelay;
    public int MaxDestinationAttempts => maxDestinationAttempts;

    public float DesireToLeave => desireToLeave;
    public float MaxLeavePoints => maxLeavePoints;

    public List<AgentTag> tags = new();
    public bool IsLeavingTown => isLeavingTown;

    // ✅ NEW: which tags make this agent flee if an attacker carrying them lands a hit
    public List<AgentTag> scaredOfTags = new();
    public List<AgentTag> ScaredOfTags => scaredOfTags;

    // ✅ NEW: fear-recovery state. Only used for residents who ran home — outsiders
    // who leave town via AgentLeaving never come back, so they don't need this.
    public bool isFrightened = false;
    public Agent fearSource = null;
    [SerializeField] public float safeDistanceFromFear = 5f;
    public bool IsLeaveFadeStarted => leaveFadeStarted;
    public Vector3 LeaveDestinationWorld => leaveDestinationWorld;
    public float MoveSpeed => moveSpeed;
    public float LeaveWalkSpeedMultiplier => leaveWalkSpeedMultiplier;
    public float LeaveFadeSpeed => leaveFadeSpeed;


    public Building myWorkplace;
    public AgentWorkSchedule WorkSchedule;

    public Agent interactionTarget;

    //   public AgentMovement movement;
    //   public AgentCombat combat;
    public AgentVisuals Visuals;
    public AgentSpending Spending;
    public AgentSchedule Schedule;
    public ActionManager Actions;
    public Animator animator;

    public Dictionary<InteractionType, float>
    socialProgress = new Dictionary<InteractionType, float>();

    public Dictionary<InteractionType, Agent>
    currentTarget = new Dictionary<InteractionType, Agent>();

    [SerializeField]
    public List<InventoryItem> inventory =
    new List<InventoryItem>();


    private void Awake()
    {
        if (spriteRenderer == null)
            spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        Visuals = new AgentVisuals(this, animator);
        Spending = new AgentSpending(this);
        Schedule = new AgentSchedule(this);
        Actions = new ActionManager(this);

        Visuals.Init();

        if (spriteRenderer == null)
            spriteRenderer = GetComponentInChildren<SpriteRenderer>();

        noiseOffset = UnityEngine.Random.Range(0f, 1000f);

        if (spriteRenderer != null)
            spriteRenderer.flipX = false;
    }

    private void Start()
    {
        lastFramePosition = transform.position;
        InClearAllStatTypes();

        // ✅ FIX: if something already placed this agent (e.g. a pen animal spawned
        // and placed in the same frame, before Start() ran), don't let the normal
        // role-setup / wander-pick logic below undo it.
        SetRole(type, preservePlacement: hasExplicitPlacement);

        if (isDead)
        {
            Visuals.RefreshDeathVisuals();
            return;
        }

        if (!hasExplicitPlacement)
            AgentPathing.PickNewDestination(this);

        WorkSchedule = new AgentWorkSchedule(this);
    }

    private void Update()
    {
        if (isDead)
            return;
        Visuals.UpdateVisualState();
        Schedule.RunSchedules();


        if (isLeavingTown)
        {
            AgentLeaving.UpdateLeaving(this);
            return;
        }

        AgentFear.UpdateFear(this);
        AgentMovement.UpdateMovement(this);
    }

    private void LateUpdate()
    {
        Visuals.UpdateSorting();
    }

    private void OnMouseDown()
    {
        if (isDead)
            return;

        AgentTrading.HandleClick(this);
    }

    private void OnDestroy()
    {
        AgentTeams.DeregisterTeamMember(this);

        if (GameManager.Instance != null)
            GameManager.Instance.DeregisterAgent(this);
    }


    #region ATTRIBUTES
    public Agent GetCurrentTarget(
        InteractionType interactionType)
    {
        if (currentTarget.TryGetValue(
                interactionType,
                out Agent target))
        {
            return target;
        }

        return null;
    }

    public void SetCurrentTarget(
        InteractionType interactionType,
        Agent target)
    {
        if (target == null)
        {
            currentTarget.Remove(
                interactionType);

            return;
        }

        currentTarget[
            interactionType] = target;
    }

    public void ClearCurrentTarget(
        InteractionType interactionType)
    {
        currentTarget.Remove(
            interactionType);
    }

    public float GetSocialProgress(
        InteractionType interactionType)
    {
        if (socialProgress.TryGetValue(
                interactionType,
                out float progress))
        {
            return progress;
        }

        return 0f;
    }

    public void AddSocialProgress(
        InteractionType interactionType,
        float amount)
    {
        if (amount <= 0f)
            return;

        if (!socialProgress.ContainsKey(
                interactionType))
        {
            socialProgress[
                interactionType] = 0f;
        }

        socialProgress[
            interactionType] += amount;
    }


    private void InClearAllStatTypes()
    {
        foreach (scoreType score in Enum.GetValues(typeof(scoreType)))
        {
            if (!AgentStats.ContainsKey(score))
                AgentStats.Add(score, 0);
            else
                AgentStats[score] = 0;
        }

        foreach (AgentType agentType in Enum.GetValues(typeof(AgentType)))
        {
            if (!BuysFrom.ContainsKey(agentType))
                BuysFrom.Add(agentType, 0);
            else
                BuysFrom[agentType] = 0;
        }
    }


    public bool HasTag(AgentTag tag)
    {
        return tags.Contains(tag);
    }

    public bool HasAnyTag(List<AgentTag> checkTags)
    {
        if (checkTags == null)
            return false;

        foreach (var tag in checkTags)
        {
            if (tags.Contains(tag))
                return true;
        }

        return false;
    }

    #region INVENTORY & CARRYING

    // Total amount of harvested loot currently carried. The agent's own items
    // (isLoot == false) never count toward carry capacity.
    public int CarriedLoot
    {
        get
        {
            int total = 0;

            if (inventory == null)
                return 0;

            foreach (InventoryItem item in inventory)
            {
                if (item != null && item.isLoot)
                    total += item.amount;
            }

            return total;
        }
    }

    public int FreeCarryCapacity =>
        Mathf.Max(0, maxCarryCapacity - CarriedLoot);

    // Stacks are matched on type AND isLoot, so harvested meat never merges
    // into the agent's own meat.
    public void AddToInventory(
        ObjectType type,
        int amount,
        bool isLoot = false)
    {
        if (amount <= 0)
            return;

        if (inventory == null)
            inventory = new List<InventoryItem>();

        foreach (InventoryItem item in inventory)
        {
            if (item == null ||
                item.type != type ||
                item.isLoot != isLoot)
            {
                continue;
            }

            item.amount += amount;
            return;
        }

        inventory.Add(
            new InventoryItem(
                type,
                amount,
                isLoot));
    }

    // Extraction path: adds to THIS agent as loot, up to the carry limit.
    // Returns how many were actually taken so the caller can subtract exactly
    // that from the source.
    public int AddLoot(ObjectType type, int amount)
    {
        int accepted = Mathf.Min(amount, FreeCarryCapacity);

        if (accepted <= 0)
            return 0;

        AddToInventory(type, accepted, isLoot: true);
        return accepted;
    }

    // Removes and returns all carried loot; leaves the agent's own items untouched.
    public List<InventoryItem> TakeAllLoot()
    {
        var taken = new List<InventoryItem>();

        if (inventory == null)
            return taken;

        for (int i = inventory.Count - 1; i >= 0; i--)
        {
            InventoryItem item = inventory[i];

            if (item == null || !item.isLoot || item.amount <= 0)
                continue;

            taken.Add(item);
            inventory.RemoveAt(i);
        }

        return taken;
    }

    public bool HasInventoryItems()
    {
        if (inventory == null)
            return false;

        foreach (InventoryItem item in inventory)
        {
            if (item != null &&
                item.amount > 0)
            {
                return true;
            }
        }

        return false;
    }

    // On death, the body's drops (ScriptableAgent.startingInventory) become the
    // corpse's own normal items. They only turn into loot once a harvester
    // extracts them (AddLoot).
    private void FillCorpseInventory()
    {
        ScriptableAgent data = AgentData.Instance != null
            ? AgentData.Instance.GetAgent(type)
            : null;

        if (data == null || data.startingInventory == null)
            return;

        foreach (InventoryItem drop in data.startingInventory)
        {
            if (drop == null || drop.amount <= 0)
                continue;

            AddToInventory(drop.type, drop.amount, isLoot: false);
        }
    }

    #endregion

    public void SetRole(AgentType newType, bool preservePlacement = false)
    {
        AgentTeams.DeregisterTeamMember(this);

        if (GameManager.Instance != null)
            GameManager.Instance.DeregisterAgent(this);

        type = newType;

        var data = AgentData.Instance != null ? AgentData.Instance.GetAgent(type) : null;
        InClearAllStatTypes();

        preferredBuildingTypes.Clear();
        spendBehaviours.Clear();
        isOnSpendTrip = false;
        activeSpendBehaviourIndex = -1;
        activeSpendAmount = 0f;
        hasForcedSpendDestination = false;
        spendTickAccumulator = 0f;
        leaveTickAccumulator = 0f;
        desireToLeave = 0f;
        isLeavingTown = false;
        leaveFadeStarted = false;
        leaveDestinationWorld = Vector3.zero;
        Actions.Reset();

        // a role swap shouldn't carry old tracked/attack targets into the new role
        currentTarget.Clear();

        // ✅ don't let a stale movement/roam state survive a role swap —
        // unless the caller explicitly wants to keep a placement (e.g. pen animal spawn)
        if (!preservePlacement)
        {
            movementType = MovementType.AvoidAllBuildings;
            targetTile = Vector2Int.zero;
            roamInsideTarget = false;
        }

        isFrightened = false;
        fearSource = null;

        team = data != null ? data.team : TeamType.none;
        visualTint = data != null ? data.debugColor : Color.white;
        attackVisualTimer = 0f;

        // copy, don't alias — otherwise runtime tag changes would edit the
        // ScriptableObject asset, and a missing data entry would throw here
        tags = data != null && data.tags != null
            ? new List<AgentTag>(data.tags)
            : new List<AgentTag>();

        scaredOfTags = data != null && data.scaredOfTags != null
            ? new List<AgentTag>(data.scaredOfTags)
            : new List<AgentTag>();

        maxCarryCapacity = data != null ? data.carryCapacity : 10;

        if (data != null)
        {
            if (data.hangsAround != null)
                preferredBuildingTypes.AddRange(data.hangsAround);

            if (data.stats != null)
            {
                foreach (var agentStat in data.stats)
                {
                    Debug.Log($"⛏ updated stat {agentStat.typeOfScore} to {agentStat.amount}");
                    AgentStats[agentStat.typeOfScore] = agentStat.amount;
                }
            }

            if (data.spendsAt != null)
            {
                foreach (var spend in data.spendsAt)
                    spendBehaviours.Add(spend);
            }
        }

        Visuals.ApplyVisuals();
        Visuals.RefreshDeathVisuals();

        if (team != TeamType.none)
            AgentTeams.RegisterTeamMember(this, team);

        if (GameManager.Instance != null)
            GameManager.Instance.RegisterAgent(this);
    }

    public void SetDeadState(deathType newDeathType)
    {
        AgentTeams.DeregisterTeamMember(this);

        // only fill the corpse on the alive -> dead transition, so a repeat
        // call can't duplicate the drops
        bool wasAlive = !isDead;

        isDead = true;
        causeOfDeath = newDeathType;
        health = 0f;

        if (wasAlive)
            FillCorpseInventory();

        attackVisualTimer = 0f;

        isOnSpendTrip = false;
        activeSpendBehaviourIndex = -1;
        activeSpendAmount = 0f;
        hasForcedSpendDestination = false;

        isLeavingTown = false;
        leaveFadeStarted = false;
        leaveDestinationWorld = Vector3.zero;

        spendTickAccumulator = 0f;
        leaveTickAccumulator = 0f;
        desireToLeave = 0f;

        Actions.Reset();

        // a dead agent shouldn't keep tracked/attack targets
        currentTarget.Clear();

        // ✅ same reason as SetRole — a dead agent shouldn't carry roam/combat state
        movementType = MovementType.AvoidAllBuildings;
        targetTile = Vector2Int.zero;
        roamInsideTarget = false;
        hasExplicitPlacement = false;
        isFrightened = false;
        fearSource = null;

        AgentMovement.ClearPath(this);
        waitTimer = 0f;
        currentSpeed = 0f;
        steeringVelocity = Vector3.zero;
        stuckTimer = 0f;
        lastDistanceToTarget = -1f;
        hasDistanceSample = false;

        Visuals.RefreshDeathVisuals();
    }

    public void SetAliveState()
    {
        isDead = false;
        causeOfDeath = deathType.starve;
        health = 100f;

        attackVisualTimer = 0f;

        if (team != TeamType.none)
            AgentTeams.RegisterTeamMember(this, team);

        Visuals.ApplyVisuals();
        Visuals.RefreshDeathVisuals();
        Visuals.SetSpriteAlpha(1f);
    }
    #endregion

    public TargetKind Kind => TargetKind.Agent;
    public bool Exists => this != null && !isLeavingTown;
    public Vector3 WorldPosition => transform.position;

    public bool MatchesFilter(AgentInteraction interaction)
    {
        return interaction != null && HasAnyTag(interaction.targetTags);
    }

    public bool TryGetApproach(Agent from, AgentInteraction interaction, out Vector2Int tile, out Vector3 world)
    {
        world = transform.position;
        tile = AgentPathing.WorldToGrid(from, world);
        return true;
    }

    public void TakeDamage(float amount, deathType cause)
    {
        AgentDeath.HurtAgent(this, cause, amount);
    }

    public float GetGameTickLength()
    {
        if (Settings.Instance == null)
            return 1f;

        return Mathf.Max(0.01f, Settings.Instance.gameTickLength);
    }

#if UNITY_EDITOR
    private void OnDrawGizmos()
    {
        if (!drawPathGizmos)
            return;

        if (hasForcedSpendDestination)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawSphere(AgentPathing.GridToWorld(this, forcedSpendDestinationTile), 0.08f);
        }

        if (isLeavingTown)
        {
            Gizmos.color = Color.white;
            Gizmos.DrawWireSphere(LevelCreator.Instance != null ? LevelCreator.Instance.transform.position : Vector3.zero,
                                  LevelCreator.Instance != null ? LevelCreator.Instance.LeaveRadius : 0f);
            Gizmos.color = Color.cyan;
            Gizmos.DrawSphere(leaveDestinationWorld, 0.1f);
        }

        if (currentPath == null || currentPath.Count == 0)
            return;

        Gizmos.color = isOnSpendTrip ? Color.red : Color.cyan;
        for (int i = 0; i < currentPath.Count - 1; i++)
            Gizmos.DrawLine(currentPath[i], currentPath[i + 1]);

        Gizmos.color = isOnSpendTrip ? new Color(1f, 0.35f, 0.35f, 1f) : Color.yellow;
        foreach (var point in currentPath)
            Gizmos.DrawSphere(point, 0.05f);

        if (pathIndex < currentPath.Count)
        {
            Gizmos.color = isOnSpendTrip ? Color.red : Color.green;
            Gizmos.DrawSphere(currentPath[pathIndex], 0.1f);
            Gizmos.DrawLine(transform.position, currentPath[pathIndex]);
        }

        Gizmos.color = Color.red;
        Gizmos.DrawSphere(currentPath[currentPath.Count - 1], 0.12f);

        Handles.color = isOnSpendTrip ? Color.red : Color.white;

        string modeText = isOnSpendTrip
            ? "SPENDING"
            : isLeavingTown
                ? "LEAVING"
                : isDead
                    ? $"DEAD ({causeOfDeath})"
                    : "HANGING OUT";

        string tickText = isOnSpendTrip
            ? "Tick: paused while buying"
            : $"Tick left: {Spending.GetSpendTickRemaining():0.00}s";

        Handles.Label(
            transform.position + Vector3.up * 0.85f,
            $"{modeText}\n{tickText}\nLeave: {desireToLeave:0.00}/{maxLeavePoints:0.##}"
        );
    }
#endif
}
