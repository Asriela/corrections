// GameManager.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    [Serializable]
    private struct StartingCardEntry
    {
        public BuildingType buildingType;
        public int count;
    }

    public bool GameOver = false;
    public static int CurrentLevelIndex = 0;

    public GameObject visualEffect_prefab;

    public Dictionary<BuildingType, List<Building>> AllBuildings = new();
    public Dictionary<AgentType, List<Agent>> AllAgents = new();

    // Finite deck counts: BuildingType -> remaining cards
    public static Dictionary<BuildingType, int> CardsInDeck = new();



    [Header("Starting Deck")]
    [SerializeField] private List<StartingCardEntry> startingDeck = new();

    [SerializeField] public List<BuildingType> LevelUpOptions = new();

    public GameObject MapController;
    public GameObject prefabMapTown;

    public static float PlayingGold = 0;
    public static float PlayingFood = 200;
    public static float PlayingGoodWill = 0;

    public static List<MapTownData> townsOnMap = new();

    public static Dictionary<ResourceType, int> SavedCurrentPositionResources = new();
    public static Vector3 SavedMapPosition = Vector3.zero;
    public static bool HasSavedMapResources = false;

    public bool IsPointerOverUI;

    [SerializeField] private GameObject agentPrefabs;

    public HashSet<Vector2Int> OccupiedTiles { get; private set; } = new();

    private readonly Dictionary<Vector2Int, Building> tileToBuilding = new();
    private readonly Dictionary<Vector2Int, Resource> tileToResource = new();

    private readonly Dictionary<Building, List<Vector2Int>> buildingToZoneTiles = new();
    public Dictionary<BuildingType, List<Vector2Int>> BuildingZones = new();

    private readonly Dictionary<BuildingType, Dictionary<Vector2Int, int>> zoneTileCountsByType = new();
    public Biome LevelBiome;

    private bool rolesDirty = true;

    public static bool HasCardType(BuildingType type){
        return CardsInDeck[type] > 0;
        }

    public bool RolesDirty
    {
        get => rolesDirty;
        set
        {
            if (rolesDirty != value)
            {
                rolesDirty = value;
            }
        }
    }

    public bool OverUI = false;
    public float ClickDelay = 0f;

    private void Update()
    {
        if (ClickDelay > 0f)
            ClickDelay -= Time.deltaTime;
    }

    protected override void Awake()
    {
        base.Awake();
        InitializeAllDictionaries();
        LocationRegistry.Clear();
        SetupStartingBuildings();
    }

    private void InitializeAllDictionaries()
    {
        foreach (BuildingType type in Enum.GetValues(typeof(BuildingType)))
        {
            if (!AllBuildings.ContainsKey(type))
                AllBuildings[type] = new List<Building>();

            if (!BuildingZones.ContainsKey(type))
                BuildingZones[type] = new List<Vector2Int>();

            if (!zoneTileCountsByType.ContainsKey(type))
                zoneTileCountsByType[type] = new Dictionary<Vector2Int, int>();
        }

        foreach (AgentType type in Enum.GetValues(typeof(AgentType)))
        {
            if (!AllAgents.ContainsKey(type))
                AllAgents[type] = new List<Agent>();
        }

        if (SavedCurrentPositionResources == null)
            SavedCurrentPositionResources = new Dictionary<ResourceType, int>();

        if (CardsInDeck == null)
            CardsInDeck = new Dictionary<BuildingType, int>();
    }

    public static void SaveCurrentMapResources(Dictionary<ResourceType, int> source, Vector3 mapPosition)
    {
        SavedCurrentPositionResources = new Dictionary<ResourceType, int>();

        foreach (ResourceType resource in Enum.GetValues(typeof(ResourceType)))
        {
            int amount = 0;
            if (source != null && source.TryGetValue(resource, out int value))
                amount = value;

            SavedCurrentPositionResources[resource] = amount;
        }

        SavedMapPosition = mapPosition;
        HasSavedMapResources = true;
    }

    public static Dictionary<ResourceType, int> GetSavedCurrentPositionResourcesCopy()
    {
        if (SavedCurrentPositionResources == null)
            return new Dictionary<ResourceType, int>();

        return new Dictionary<ResourceType, int>(SavedCurrentPositionResources);
    }

    public GameObject CreateObject(GameObject prefab, Vector3 position)
    {
        return Instantiate(prefab, position, Quaternion.identity);
    }

    public Agent SpawnAgent(AgentType type, Vector3 position)
    {
        var agent = CreateObject(agentPrefabs, position).GetComponent<Agent>();
        agent.type = type;
        return agent;
    }

    // -------------------------
    // BUILDINGS
    // -------------------------
    public void RegisterBuilding(Building building)
    {
        if (building == null)
            return;

        if (!AllBuildings.ContainsKey(building.type))
            AllBuildings[building.type] = new List<Building>();

        if (!AllBuildings[building.type].Contains(building))
            AllBuildings[building.type].Add(building);
    }

    public void RegisterBuilding(Building building, Vector2Int tile)
    {
        if (building == null)
            return;

        RegisterBuilding(building);

        // FOOTPRINT: register every tile the building occupies, not just the
        // anchor tile it was passed. `tile` is expected to already equal
        // building.GridPosition (BuildingPlacer calls SetGridPosition before
        // this), so GetOccupiedTiles() is authoritative here. For a 1x1
        // building this loop runs exactly once with `tile` itself — identical
        // to the old behaviour.
        foreach (Vector2Int occupied in building.GetOccupiedTiles())
        {
            tileToBuilding[occupied] = building;
            OccupiedTiles.Add(occupied);
        }
    }

    public void RegisterBuildingTiles(Building building, List<Vector2Int> tiles)
    {
        if (building == null || tiles == null || tiles.Count == 0)
            return;

        // RegisterBuilding/RegisterBuildingZones both derive the full
        // footprint from `building` itself now (GridPosition + footprintSize),
        // so tiles[0] only needs to be the anchor — the rest of `tiles` is
        // effectively redundant with building.GetOccupiedTiles(), but kept
        // as the entry point in case external callers rely on this overload.
        RegisterBuilding(building, tiles[0]);
        RegisterBuildingZones(building, tiles[0]);
    }

    public void RegisterBuildingZones(Building building, Vector2Int originTile)
    {
        if (building == null)
            return;

        DeregisterBuildingZones(building);

        // `originTile` is kept for call-site compatibility, but the zone ring
        // is always computed from the building's own footprint so it stays
        // correct even if a caller passes a stale/mismatched tile.
        List<Vector2Int> zoneTiles = GetOrthogonalZoneTiles(building);
        buildingToZoneTiles[building] = zoneTiles;

        foreach (Vector2Int tile in zoneTiles)
        {
            if (!IsWithinBounds(tile))
                continue;

            if (IsTileOccupied(tile))
                continue;

            AddZoneTile(building.type, tile);
        }
    }

    public void DeregisterBuilding(Building building)
    {
        if (building == null)
            return;

        DeregisterBuildingZones(building);

        if (AllBuildings.ContainsKey(building.type))
            AllBuildings[building.type].Remove(building);

        if (building.GridPosition.x != int.MinValue)
        {
            // FOOTPRINT: clear every tile the building occupied, mirroring
            // RegisterBuilding above. For a 1x1 building this is exactly the
            // one tile it used to clear.
            foreach (Vector2Int tile in building.GetOccupiedTiles())
            {
                if (tileToBuilding.TryGetValue(tile, out var ownedBy) && ownedBy == building)
                    tileToBuilding.Remove(tile);

                OccupiedTiles.Remove(tile);
            }
        }
    }

    public void DeregisterBuildingZones(Building building)
    {
        if (building == null)
            return;

        if (!buildingToZoneTiles.TryGetValue(building, out List<Vector2Int> tiles))
            return;

        foreach (Vector2Int tile in tiles)
        {
            RemoveZoneTile(building.type, tile);
        }

        buildingToZoneTiles.Remove(building);
    }

    // FOOTPRINT: the zone ring used to be just the 4 orthogonal neighbours of
    // a single origin tile. For any width x height building (square or not —
    // this loop doesn't care) it's now the outer ring surrounding the WHOLE
    // footprint — every orthogonal neighbour of every occupied tile, minus
    // any neighbour that's itself part of the same building's own footprint
    // (which matters once the footprint is bigger than 1x1, since e.g. tile
    // (1,0) of a 2x1 building is an orthogonal neighbour of tile (0,0) in
    // the same footprint). For a 1x1 building the footprint set has exactly
    // one tile, so no neighbour can ever collide with it and this produces
    // the identical 4-tile ring as before.
    private List<Vector2Int> GetOrthogonalZoneTiles(Building building)
    {
        HashSet<Vector2Int> footprintTiles = new HashSet<Vector2Int>(building.GetOccupiedTiles());
        HashSet<Vector2Int> zoneSet = new HashSet<Vector2Int>();

        foreach (Vector2Int occupied in footprintTiles)
        {
            Vector2Int[] neighbors =
            {
                new Vector2Int(occupied.x, occupied.y + 1),
                new Vector2Int(occupied.x, occupied.y - 1),
                new Vector2Int(occupied.x - 1, occupied.y),
                new Vector2Int(occupied.x + 1, occupied.y)
            };

            foreach (Vector2Int neighbor in neighbors)
            {
                if (footprintTiles.Contains(neighbor))
                    continue;

                zoneSet.Add(neighbor);
            }
        }

        return new List<Vector2Int>(zoneSet);
    }

    private void AddZoneTile(BuildingType type, Vector2Int tile)
    {
        if (!zoneTileCountsByType.ContainsKey(type))
            zoneTileCountsByType[type] = new Dictionary<Vector2Int, int>();

        if (!BuildingZones.ContainsKey(type))
            BuildingZones[type] = new List<Vector2Int>();

        Dictionary<Vector2Int, int> counts = zoneTileCountsByType[type];

        if (counts.TryGetValue(tile, out int current))
        {
            counts[tile] = current + 1;
            return;
        }

        counts[tile] = 1;
        BuildingZones[type].Add(tile);
    }

    private void RemoveZoneTile(BuildingType type, Vector2Int tile)
    {
        if (!zoneTileCountsByType.TryGetValue(type, out Dictionary<Vector2Int, int> counts))
            return;

        if (!counts.TryGetValue(tile, out int current))
            return;

        current--;

        if (current <= 0)
        {
            counts.Remove(tile);

            if (BuildingZones.TryGetValue(type, out List<Vector2Int> list))
                list.Remove(tile);
        }
        else
        {
            counts[tile] = current;
        }
    }

    public bool TryGetBuildingAt(Vector2Int tile, out Building building)
    {
        return tileToBuilding.TryGetValue(tile, out building) && building != null;
    }

    public bool TryGetPreferredHangoutTile(
        IReadOnlyList<BuildingType> preferredTypes,
        Vector3 roamCenter,
        float roamRadius,
        int searchRadiusTiles,
        out Vector2Int chosenTile)
    {
        chosenTile = default;

        if (preferredTypes == null || preferredTypes.Count == 0)
            return false;

        List<Vector2Int> candidates = new();

        foreach (BuildingType type in preferredTypes)
        {
            if (!BuildingZones.TryGetValue(type, out List<Vector2Int> zonedTiles))
                continue;

            for (int i = 0; i < zonedTiles.Count; i++)
            {
                Vector2Int tile = zonedTiles[i];

                if (!IsWithinBounds(tile))
                    continue;

                if (IsTileOccupied(tile))
                    continue;

                Vector3 worldPos = GridToWorld(tile);
                worldPos.z = roamCenter.z;

                if ((worldPos - roamCenter).sqrMagnitude > roamRadius * roamRadius)
                    continue;

                candidates.Add(tile);
            }
        }

        if (candidates.Count == 0)
            return false;

        chosenTile = candidates[UnityEngine.Random.Range(0, candidates.Count)];
        return true;
    }

    // -------------------------
    // RESOURCES
    // -------------------------
    public void RegisterResource(Resource resource, Vector2Int tile)
    {
        if (resource == null)
            return;

        tileToResource[tile] = resource;
        OccupiedTiles.Add(tile);
    }

    public void DeregisterResource(Vector2Int tile)
    {
        tileToResource.Remove(tile);
        OccupiedTiles.Remove(tile);
    }

    public bool TryGetResourceAt(Vector2Int tile, out Resource resource)
    {
        return tileToResource.TryGetValue(tile, out resource) && resource != null;
    }

    public bool HasAnyResource(ResourceType type)
    {
        foreach (var kvp in tileToResource)
        {
            if (kvp.Value == null)
                continue;

            if (kvp.Value.type == type)
                return true;
        }

        return false;
    }

    public bool TryConsumeResourceAt(Vector2Int tile, ResourceType requiredType)
    {
        if (!TryGetResourceAt(tile, out Resource resource))
            return false;

        if (resource == null || resource.type != requiredType)
            return false;

        DeregisterResource(tile);
        Destroy(resource.gameObject);
        Debug.Log($"Consumed resource {requiredType} at tile {tile}");
        return true;
    }

    public bool TryConsumeNearestResource(ResourceType type, Vector3 origin)
    {
        Vector2Int bestTile = default;
        Resource bestResource = null;
        float bestSqrDist = float.MaxValue;

        foreach (var kvp in tileToResource)
        {
            Resource resource = kvp.Value;
            if (resource == null)
                continue;

            if (resource.type != type)
                continue;

            float sqrDist = (resource.transform.position - origin).sqrMagnitude;
            if (sqrDist < bestSqrDist)
            {
                bestSqrDist = sqrDist;
                bestTile = kvp.Key;
                bestResource = resource;
            }
        }

        if (bestResource == null)
            return false;

        DeregisterResource(bestTile);
        Destroy(bestResource.gameObject);
        Debug.Log($"Consumed nearest {type} resource at tile {bestTile}");
        return true;
    }

    public bool IsTileOccupied(Vector2Int tile)
    {
        return OccupiedTiles.Contains(tile)
               || tileToBuilding.ContainsKey(tile)
               || tileToResource.ContainsKey(tile);
    }

    private Vector3 GridToWorld(Vector2Int gridPos)
    {
        Vector2 cellSize = Vector2.one;

        if (BuildingPlacer.Instance != null)
            cellSize = BuildingPlacer.Instance.cellSize;

        return new Vector3(
            gridPos.x * cellSize.x,
            gridPos.y * cellSize.y,
            0f
        );
    }

    private bool IsWithinBounds(Vector2Int tile)
    {
        if (BuildingPlacer.Instance == null)
            return true;

        int halfW = BuildingPlacer.Instance.gridWidth / 2;
        int halfH = BuildingPlacer.Instance.gridHeight / 2;

        return tile.x >= -halfW && tile.x <= halfW &&
               tile.y >= -halfH && tile.y <= halfH;
    }

    // -------------------------
    // AGENTS
    // -------------------------
    public void RegisterAgent(Agent agent)
    {
        if (agent == null)
            return;

        if (!AllAgents.ContainsKey(agent.type))
            AllAgents[agent.type] = new List<Agent>();

        if (!AllAgents[agent.type].Contains(agent))
            AllAgents[agent.type].Add(agent);
    }

    public void DeregisterAgent(Agent agent)
    {
        if (agent == null)
            return;

        if (AllAgents.ContainsKey(agent.type))
            AllAgents[agent.type].Remove(agent);
    }

    private void SetupStartingBuildings()
    {
        if (CardsInDeck == null)
            CardsInDeck = new Dictionary<BuildingType, int>();
        else
            CardsInDeck.Clear();

        // If you fill the inspector list, those values are used.
        // Otherwise this fallback gives you a working starter deck.
        if (startingDeck != null && startingDeck.Count > 0)
        {
            foreach (var entry in startingDeck)
            {
                if (entry.buildingType == BuildingType.none)
                    continue;

                int count = Mathf.Max(0, entry.count);
                if (count <= 0)
                    continue;

                if (CardsInDeck.TryGetValue(entry.buildingType, out int existing))
                    CardsInDeck[entry.buildingType] = existing + count;
                else
                    CardsInDeck[entry.buildingType] = count;
            }

            return;
        }

        SetCardCount(BuildingType.house, 3);
        SetCardCount(BuildingType.farm, 3);
        SetCardCount(BuildingType.tradepost, 2);
        SetCardCount(BuildingType.saloon, 1);
    }

    public static int GetCardCount(BuildingType type)
    {
        if (CardsInDeck == null)
            return 0;

        return CardsInDeck.TryGetValue(type, out int count) ? Mathf.Max(0, count) : 0;
    }

    public static void SetCardCount(BuildingType type, int count)
    {
        if (CardsInDeck == null)
            CardsInDeck = new Dictionary<BuildingType, int>();

        count = Mathf.Max(0, count);

        if (count <= 0)
        {
            CardsInDeck.Remove(type);
            return;
        }

        CardsInDeck[type] = count;
    }

    public static bool TryConsumeCard(BuildingType type)
    {
        if (CardsInDeck == null)
            CardsInDeck = new Dictionary<BuildingType, int>();

        if (!CardsInDeck.TryGetValue(type, out int count))
            return false;

        count--;

        if (count <= 0)
            CardsInDeck.Remove(type);
        else
            CardsInDeck[type] = count;

        return true;
    }

    public void RestartGame()
    {
        PlayingGold = 0;
        PlayingFood = 0;
        PlayingGoodWill = 0;
        townsOnMap.Clear();

        if (CardsInDeck != null)
            CardsInDeck.Clear();

        SetupStartingBuildings();

        CurrentLevelIndex = 0;
        PlayerOnMap.hasSavedState = false;
        PlayerOnMap.savedTrailPoints.Clear();
        SavedCurrentPositionResources.Clear();
        HasSavedMapResources = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void NextLevel()
    {
        CurrentLevelIndex++;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
