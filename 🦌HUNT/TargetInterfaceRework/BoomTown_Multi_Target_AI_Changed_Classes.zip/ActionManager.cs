// ActionManager.cs
using System.Collections.Generic;
using UnityEngine;

// ActionManager.cs — class ActionManager
public class ActionManager
{
    private readonly Agent agent;

    private AgentInteraction activeInteraction;
    private int activeInteractionIndex = -1;
    private IInteractionTarget activeTarget;

    private float decisionTickAccumulator = 0f;
    private readonly List<float> cooldownTimers = new List<float>();

    public Agent CurrentTarget => activeTarget as Agent;
    public IInteractionTarget CurrentInteractionTarget => activeTarget;
    public bool HasActivePlan => activeInteraction != null && activeTarget != null && activeTarget.Exists;

    public ActionManager(Agent agent)
    {
        this.agent = agent;
        decisionTickAccumulator = Random.Range(0f, Mathf.Max(0.01f, agent.interactionDecisionInterval));
    }

    public void UpdateActions()
    {
        if (agent.isDead || agent.isLeavingTown)
        {
            ResetAllState();
            return;
        }

        AdvanceCooldowns();

        var data = AgentData.Instance?.GetAgent(agent.type);
        if (data == null || data.interactions == null || data.interactions.Count == 0)
            return;

        SyncCooldownListLength(data.interactions.Count);

        if (activeTarget != null)
        {
            PursueActivePlan();
            return;
        }

        decisionTickAccumulator += Time.deltaTime;
        if (decisionTickAccumulator < agent.interactionDecisionInterval)
            return;

        decisionTickAccumulator = 0f;
        SelectAction(data);
    }

    // =====================================================
    // 🧠 SELECTION
    //
    // Per interaction, cheapest check first:
    //   cooldown -> can't-win-on-priority -> conditions -> chance -> target
    //
    // Conditions are all self-only (see ActionConditions), so they run
    // BEFORE the target search. A missing target just drops that
    // interaction; the next-best one still gets its turn.
    // =====================================================
    private void SelectAction(ScriptableAgent data)
    {
        AgentInteraction chosen = null;
        int chosenIndex = -1;
        IInteractionTarget chosenTarget = null;
        int bestPriority = int.MinValue;

        for (int i = 0; i < data.interactions.Count; i++)
        {
            var interaction = data.interactions[i];

            if (cooldownTimers[i] > 0f)
                continue;

            if ((int)interaction.priority <= bestPriority)
                continue; // can't beat what we already have, skip the work

            if (!SocialActions.Supports(interaction.type, interaction.targetKind))
                continue;
            if (!ActionConditions.AllMet(agent, interaction))
                continue;

            if (Random.value > interaction.chance)
                continue;

            IInteractionTarget target = ResolveTarget(interaction);
            if (target == null || !target.Exists)
                continue;

            bestPriority = (int)interaction.priority;
            chosen = interaction;
            chosenIndex = i;
            chosenTarget = target;
        }

        if (chosen == null)
            return;

        // Committed here, not during the search, so a Track candidate that
        // loses on priority can't change the current target.
        if (chosen.type == InteractionType.Track)
            agent.SetCurrentTarget(InteractionType.Track, chosenTarget as Agent);

        activeInteraction = chosen;
        activeInteractionIndex = chosenIndex;
        activeTarget = chosenTarget;

        PursueActivePlan();
    }

    // =====================================================
    // 🎯 TARGET RESOLUTION — one case per interaction type.
    //
    // Each case owns HOW that interaction finds someone. Returning null means
    // "nothing to act on": SelectAction drops that interaction this tick and
    // the next-best one gets its turn.
    //
    // To give an interaction its own search, add a case and a Resolve___
    // method. Every resolver should finish by running its candidate through
    // IsValidTarget so the dead/alive and tag rules stay in one place.
    // =====================================================
    private IInteractionTarget ResolveTarget(AgentInteraction interaction)
    {
        switch (interaction.targetKind)
        {
            case TargetKind.Building: return ResolveBuildingTarget(interaction);
            case TargetKind.Location: return LocationRegistry.FindNearest(interaction, agent.transform.position);
            default: return ResolveAgentTarget(interaction);
        }
    }

    private Building ResolveBuildingTarget(AgentInteraction interaction)
    {
        switch (interaction.buildingTargetSelector)
        {
            case BuildingTargetSelector.MyWorkplace: return IsValidBuildingTarget(interaction, agent.myWorkplace) ? agent.myWorkplace : null;
            case BuildingTargetSelector.MyHome: return IsValidBuildingTarget(interaction, agent.myHouse) ? agent.myHouse : null;
            default: return FindNearestBuilding(interaction);
        }
    }

    private bool IsValidBuildingTarget(AgentInteraction interaction, Building building)
    {
        if (building == null || !building.Exists || building.isBroken) return false;
        return interaction.buildingTargetSelector != BuildingTargetSelector.Nearest || building.MatchesFilter(interaction);
    }

    private Building FindNearestBuilding(AgentInteraction interaction)
    {
        var all = GameManager.Instance?.AllBuildings; if (all == null) return null;
        Building nearest = null; float best = float.MaxValue; Vector3 origin = agent.transform.position;
        foreach (List<Building> list in all.Values)
        {
            if (list == null) continue;
            foreach (Building building in list)
            {
                if (!IsValidBuildingTarget(interaction, building)) continue;
                float d = (building.transform.position - origin).sqrMagnitude;
                if (d >= best) continue; best = d; nearest = building;
            }
        }
        return nearest;
    }

    private Agent ResolveAgentTarget(AgentInteraction interaction)
    {
        switch (interaction.type)
        {
            // Picks a NEW tracking target (the only interaction that does).
            case InteractionType.Track:
                return FindTrackingTarget(interaction);

            // Its own search, separate from Track: Track finds living prey,
            // this finds a corpse with something left on it to take.
            case InteractionType.HarvestAnimal:
                return FindHarvestTarget(interaction);

            // Add per-interaction finders here as they need them, e.g.:
            //   case InteractionType.Heal:             return ResolveHealTarget(interaction);       // lowest-health ally
            //   case InteractionType.FleeFrom:         return ResolveThreatTarget(interaction);     // nearest threat
            //   case InteractionType.DepositResources: return ResolveDepositTarget(interaction);    // wherever loot goes

            // Everything else keeps the old behaviour until it gets its own case:
            // tracked target if its conditions ask about it, otherwise nearest.
            default:
                return ResolveTrackedOrNearest(interaction);
        }
    }

    // The agent's current Track target, if it's still valid for this interaction.
    private Agent ResolveTrackedTarget(AgentInteraction interaction)
    {
        Agent tracked = agent.GetCurrentTarget(InteractionType.Track);
        return IsValidTarget(interaction, tracked) ? tracked : null;
    }

    // Old ResolveTarget fallback: conditions about the tracked target
    // (hasTarget / doneTrackingTarget / targetDead / targetHasInventory)
    // mean "act on the tracked target"; otherwise nearest valid agent.
    private Agent ResolveTrackedOrNearest(AgentInteraction interaction)
    {
        if (ActionConditions.UsesTrackedTarget(interaction))
            return ResolveTrackedTarget(interaction);

        return FindNearestValidTarget(interaction);
    }

    // =====================================================
    // 🎯 TARGET VALIDITY — used by the searches AND by the per-tick
    // validation while pursuing, so a plan drops itself the moment its
    // target stops being valid. One rule set per interaction type; shared
    // basics (not self, not leaving town) are checked first.
    // =====================================================
    private bool IsValidTarget(AgentInteraction interaction, Agent candidate)
    {
        if (candidate == null || candidate == agent || candidate.IsLeavingTown)
            return false;

        switch (interaction.type)
        {
            case InteractionType.HarvestAnimal:
                return IsValidHarvestTarget(interaction, candidate);

            default:
                return IsValidDefaultTarget(interaction, candidate);
        }
    }

    // Harvest: a corpse that still has something on it. If something else
    // picks it clean mid-walk, the plan drops itself.
    private bool IsValidHarvestTarget(AgentInteraction interaction, Agent candidate)
    {
        return candidate.isDead &&
               candidate.HasInventoryItems() &&
               candidate.HasAnyTag(interaction.targetTags);
    }

    // Everything else: dead targets are accepted ONLY for interactions with a
    // targetDead condition (and are required for them).
    private bool IsValidDefaultTarget(AgentInteraction interaction, Agent candidate)
    {
        if (candidate.isDead != ActionConditions.RequiresDeadTarget(interaction))
            return false;

        if (ActionConditions.RequiresTargetInventory(interaction) && !candidate.HasInventoryItems())
            return false;

        return candidate.HasAnyTag(interaction.targetTags);
    }

    private bool IsTrackable(Agent candidate, AgentInteraction interaction)
    {
        if (candidate == null ||
            candidate == agent ||
            candidate.isDead ||
            candidate.IsLeavingTown)
            return false;

        if (!candidate.HasAnyTag(interaction.targetTags))
            return false;

        if (AgentData.Instance?.GetAgent(candidate.type) == null)
            return false;

        return candidate.GetSocialProgress(InteractionType.Track) < 100f;
    }

    // No longer clears or sets the current target itself — an invalid
    // current target (dead, left town, wrong tags) is just ignored here.
    // That keeps a dead target alive in memory so it can be looted, and the
    // commit in SelectAction overwrites it when a new Track plan wins.
    private Agent FindTrackingTarget(AgentInteraction interaction)
    {
        Agent currentTrackTarget = agent.GetCurrentTarget(InteractionType.Track);

        if (currentTrackTarget != null &&
            (currentTrackTarget.isDead ||
             currentTrackTarget.IsLeavingTown ||
             !currentTrackTarget.HasAnyTag(interaction.targetTags)))
        {
            currentTrackTarget = null;
        }

        Agent bestTarget = currentTrackTarget;

        float bestScore = currentTrackTarget != null
            ? CalculateTrackingScore(currentTrackTarget, applySwitchPenalty: false)
            : float.MinValue;

        var allAgents = GameManager.Instance?.AllAgents;
        if (allAgents == null)
            return bestTarget;

        foreach (var candidates in allAgents)
        {
            foreach (Agent candidate in candidates.Value)
            {
                if (!IsTrackable(candidate, interaction))
                    continue;

                bool isDifferentTarget =
                    currentTrackTarget != null &&
                    candidate != currentTrackTarget;

                float score = CalculateTrackingScore(
                    candidate,
                    applySwitchPenalty: isDifferentTarget);

                if (score > bestScore)
                {
                    bestScore = score;
                    bestTarget = candidate;
                }
            }
        }

        return bestTarget;
    }

    private float CalculateTrackingScore(Agent target, bool applySwitchPenalty)
    {
        const float SwitchPenalty = 25f;

        if (target == null)
            return float.MinValue;

        float score = 0f;

        ScriptableAgent data = AgentData.Instance?.GetAgent(target.type);

        if (data != null && data.startingInventory != null)
        {
            foreach (InventoryItem drop in data.startingInventory)
            {
                if (drop == null)
                    continue;

                score += drop.amount;
            }
        }

        score -= Vector3.Distance(agent.transform.position, target.transform.position);

        if (applySwitchPenalty)
            score -= SwitchPenalty;

        return score;
    }

    // Plain nearest-valid search. Deliberately has NO per-interaction rules —
    // those belong in a ResolveTarget case. Validity comes from IsValidTarget only.
    private Agent FindNearestValidTarget(AgentInteraction interaction)
    {
        var allAgents = GameManager.Instance?.AllAgents;
        if (allAgents == null)
            return null;

        Agent bestTarget = null;
        float bestDist = float.MaxValue;
        Vector3 selfPos = agent.transform.position;

        foreach (var candidates in allAgents)
        {
            foreach (var candidate in candidates.Value)
            {
                if (!IsValidTarget(interaction, candidate))
                    continue;

                float dist = Vector3.Distance(selfPos, candidate.transform.position);
                if (dist < bestDist)
                {
                    bestDist = dist;
                    bestTarget = candidate;
                }
            }
        }

        return bestTarget;
    }

    // =====================================================
    // 🦴 HARVEST SEARCH — find a corpse to take loot from.
    // Our own tracked kill wins if it still has something on it (we already
    // walked there); otherwise the nearest corpse with loot left.
    // =====================================================
    private Agent FindHarvestTarget(AgentInteraction interaction)
    {
        Agent ownKill = agent.GetCurrentTarget(InteractionType.Track);
        if (IsValidTarget(interaction, ownKill))
            return ownKill;

        var allAgents = GameManager.Instance?.AllAgents;
        if (allAgents == null)
            return null;

        Agent best = null;
        float bestDist = float.MaxValue;
        Vector3 selfPos = agent.transform.position;

        foreach (var candidates in allAgents)
        {
            foreach (Agent candidate in candidates.Value)
            {
                if (!IsValidTarget(interaction, candidate))
                    continue;

                float dist = Vector3.Distance(selfPos, candidate.transform.position);
                if (dist < bestDist)
                {
                    bestDist = dist;
                    best = candidate;
                }
            }
        }

        return best;
    }

    private bool IsValidActiveTarget(AgentInteraction interaction, IInteractionTarget target)
    {
        if (interaction == null || target == null || !target.Exists || target.Kind != interaction.targetKind) return false;
        switch (target.Kind)
        {
            case TargetKind.Agent: return IsValidTarget(interaction, target as Agent);
            case TargetKind.Building: return IsValidBuildingTarget(interaction, target as Building);
            case TargetKind.Location: return target.MatchesFilter(interaction);
            default: return false;
        }
    }

    private bool ValidateActiveTarget()
    {
        return activeInteraction != null && activeTarget != null && IsValidActiveTarget(activeInteraction, activeTarget);
    }

    // =====================================================
    // 🏃 PLAN PURSUIT — proposes before executing, and registers
    // onInterrupted so a preempted plan cleans itself up automatically.
    // =====================================================
    private void PursueActivePlan()
    {
        if (!ValidateActiveTarget()) { ClearPlan(); return; }
        if (!activeTarget.TryGetApproach(agent, activeInteraction, out Vector2Int approachTile, out Vector3 approachWorld)) { ClearPlan(); return; }
        MoveTowardTarget(activeTarget, approachTile, approachWorld, activeInteraction);
        if (!IsInRange(approachWorld, activeInteraction.range)) return;
        if (!SocialActions.TryGetAction(activeInteraction.type, out AgentAction action)) { ClearPlan(); return; }
        int priority = SocialActions.GetPriority(activeInteraction.type);
        AgentInteraction callbackInteraction = activeInteraction;
        var proposition = new Proposition(action, priority, PropositionType.OneShot,
            onInterrupted: () => SocialActions.Cancel(agent, callbackInteraction));
        if (!agent.Visuals.EvaluateProposition(proposition)) return;
        SocialActions.Process(agent, activeTarget, activeInteraction);
        cooldownTimers[activeInteractionIndex] = activeInteraction.cooldown;
        ClearPlan();
    }

    private void MoveTowardTarget(IInteractionTarget target, Vector2Int tile, Vector3 world, AgentInteraction interaction)
    {
        if (target == null || !target.Exists) return;
        if (target.Kind == TargetKind.Agent) MoveTowardAgentTarget(target as Agent, tile, world, interaction);
        else MoveTowardFixedApproach(target, tile, world, interaction);
    }

    private void MoveTowardFixedApproach(IInteractionTarget target, Vector2Int tile, Vector3 world, AgentInteraction interaction)
    {
        agent.movementType = MovementType.AvoidAllBuildings; agent.roamInsideTarget = false; agent.targetTile = tile;
        ApproachTileByPathfinding(tile, world, interaction);
        agent.Visuals.UpdateFacingFromDirection(target.WorldPosition - agent.transform.position);
    }

    private void MoveTowardAgentTarget(Agent target, Vector2Int tile, Vector3 world, AgentInteraction interaction)
    {
        if (target == null) return;
        Vector3 selfPos = agent.transform.position; Vector3 targetPos = target.transform.position;
        if (interaction.canEnterTargetBuilding)
        {
            agent.movementType = MovementType.AllowTargetBuildingOnly; agent.roamInsideTarget = false; agent.targetTile = tile;
            ApproachTileByPathfinding(tile, world, interaction);
            agent.Visuals.UpdateFacingFromDirection(targetPos - selfPos); return;
        }
        agent.movementType = MovementType.AvoidAllBuildings; agent.roamInsideTarget = false; agent.targetTile = tile;
        float yDiff = Mathf.Abs(selfPos.y - targetPos.y); float xDiff = Mathf.Abs(selfPos.x - targetPos.x);
        if (yDiff <= interaction.alignmentTolerance && xDiff <= interaction.range)
        { agent.Visuals.UpdateFacingFromDirection(targetPos - selfPos); return; }
        float side = selfPos.x <= targetPos.x ? -1f : 1f; if (Mathf.Abs(selfPos.x - targetPos.x) < 0.001f) side = 1f;
        Vector3 desired = new Vector3(targetPos.x + side * interaction.standOffDistance, targetPos.y, selfPos.z);
        if (!AgentPathing.TryGetCurrentPathTarget(agent, out Vector3 current) || (current - desired).sqrMagnitude > 0.05f)
            AgentMovement.SetPath(agent, new List<Vector3> { desired });
        agent.Visuals.UpdateFacingFromDirection(targetPos - selfPos);
    }

    private void ApproachTileByPathfinding(Vector2Int goalTile, Vector3 targetWorldPos, AgentInteraction interaction)
    {
        if (Vector3.Distance(agent.transform.position, targetWorldPos) <= interaction.range)
        { if (agent.currentPath.Count > 0) AgentMovement.ClearPath(agent); return; }
        Vector2Int selfTile = AgentPathing.WorldToGrid(agent, agent.transform.position);
        if (AgentPathing.HasClearLine(agent, selfTile, goalTile))
        {
            if (!AgentPathing.TryGetCurrentPathTarget(agent, out Vector3 current) || (current - targetWorldPos).sqrMagnitude > 0.05f)
                AgentMovement.SetPath(agent, new List<Vector3> { targetWorldPos });
            return;
        }
        Vector2Int currentDestination = agent.currentPath.Count > 0 ? AgentPathing.WorldToGrid(agent, agent.currentPath[agent.currentPath.Count - 1]) : goalTile;
        if (agent.currentPath.Count > 0 && currentDestination == goalTile) return;
        if (AgentPathing.TryFindPathToTile(agent, goalTile, out List<Vector3> path)) AgentMovement.SetPath(agent, path);
    }

    private bool IsInRange(Vector3 approachWorld, float range) => Vector3.Distance(agent.transform.position, approachWorld) <= range;

    private void AdvanceCooldowns()
    {
        for (int i = 0; i < cooldownTimers.Count; i++)
        {
            if (cooldownTimers[i] > 0f)
                cooldownTimers[i] = Mathf.Max(0f, cooldownTimers[i] - Time.deltaTime);
        }
    }

    private void SyncCooldownListLength(int count)
    {
        while (cooldownTimers.Count < count)
            cooldownTimers.Add(0f);
    }

    public void CancelCurrentAction()
    {
        ClearPlan();
    }

    private void ClearPlan()
    {
        activeInteraction = null;
        activeInteractionIndex = -1;
        activeTarget = null;
    }

    private void ResetAllState()
    {
        ClearPlan();
        decisionTickAccumulator = 0f;

        for (int i = 0; i < cooldownTimers.Count; i++)
            cooldownTimers[i] = 0f;
    }

    public void Reset()
    {
        ClearPlan();
        decisionTickAccumulator = 0f;
        cooldownTimers.Clear();
    }
}
