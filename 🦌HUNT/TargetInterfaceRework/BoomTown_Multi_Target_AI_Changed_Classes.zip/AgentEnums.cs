// AgentEnums.cs
using System.Runtime.CompilerServices;

public enum AgentAction
{
    idle,
    walking,
    attack,
    bite,
    barFight,
    harvest,
    heal,
    swoon,
    convert,
    purchase,
    chat,
    laugh,
    debate,
    sleep,
    track,
    depositResources
}

public enum ObjectType
{
    Food,
    Fur
}

// ⚠️ Explicit int values on purpose: Unity saves enums in assets as ints,
// so these numbers must never shift. Gaps are removed conditions — don't
// reuse them.

public enum ActionPriority
{
    none=0,
    low=10,
    jobLow=50,
    jobMid=60,
    jobHigh=70,
    full=200,
    danger=1000

}
public enum ConditionType
{
    noCondition        = 0,
    timeOfDay          = 1,   // conditionValueToBeTrue: 1 = daytime, 0 = night
    // 2 = haveAnimal (removed)
    // 3 = hasTrackableAnimal (removed)
    doneTrackingTarget = 4,   // current Track target is alive and fully tracked -> ready to kill
    targetDead         = 5,   // current Track target is dead -> ready to loot
    carryingFullLoad   = 6,   // was carryingLoot: loot weight has reached the carry limit -> go deposit
    onDuty             = 7,   // at work (WorkSchedule.IsAtWork)
    hasTarget          = 8,   // has a current Track target (alive or dead)
    targetHasInventory = 9    // current Track target still holds items (nothing left to loot when false)
}

public enum InteractionType
{
    Combat,
    VampireBite,
    BarFight,
    Swoon,
    Heal,
    Convert,
    FleeFrom,
    HarvestAnimal,
    Track,
    DepositResources
}


public enum TargetKind { Agent = 0, Building = 1, Location = 2 }
public enum AgentTargetSelector { Nearest = 0 }
public enum BuildingTargetSelector { Nearest = 0, MyWorkplace = 1, MyHome = 2 }
public enum LocationTargetSelector { Nearest = 0 }
public enum LocationType { none = 0, townCenter = 1 }
