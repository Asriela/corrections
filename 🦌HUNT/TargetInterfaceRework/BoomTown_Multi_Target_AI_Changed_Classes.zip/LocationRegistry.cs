using System.Collections.Generic;
using UnityEngine;
public static class LocationRegistry
{
    private static readonly List<MapLocation> locations = new List<MapLocation>();
    public static void Register(MapLocation location) { if (location != null && !locations.Contains(location)) locations.Add(location); }
    public static bool Contains(MapLocation location) => location != null && locations.Contains(location);
    public static void Clear() => locations.Clear();
    public static MapLocation FindNearest(AgentInteraction interaction, Vector3 origin)
    {
        if (interaction == null) return null; MapLocation nearest = null; float best = float.MaxValue;
        foreach (MapLocation location in locations)
        {
            if (location == null || !location.MatchesFilter(interaction)) continue;
            float d = (location.position - origin).sqrMagnitude; if (d >= best) continue; best = d; nearest = location;
        }
        return nearest;
    }
}
