// SocialActions.cs
using System.Collections.Generic;
using UnityEngine;

// SocialActions.cs — interface ISocialAction
public interface ISocialAction
{
    bool Supports(TargetKind kind);
    void Execute(Agent self, IInteractionTarget target, AgentInteraction interaction);
}

public abstract class AgentTargetAction : ISocialAction
{
    public bool Supports(TargetKind kind) => kind == TargetKind.Agent;
    public void Execute(Agent self, IInteractionTarget target, AgentInteraction interaction)
    {
        if (target == null || !target.Exists) return;
        if (target is Agent agentTarget) ExecuteOnAgent(self, agentTarget, interaction);
    }
    protected abstract void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction);
}

// SocialActions.cs — class CombatAction
public class CombatAction : ISocialAction
{
    public bool Supports(TargetKind kind) => kind == TargetKind.Agent || kind == TargetKind.Building;
    public void Execute(Agent self, IInteractionTarget target, AgentInteraction interaction)
    {
        if (target == null || !target.Exists || target is not IDamageable damageable) return;
        float damage = Mathf.Max(1f, interaction.value > 0f ? interaction.value : 10f);
        damageable.TakeDamage(damage, deathType.bleeding);
        if (target is Agent agentTarget) AgentFear.TryTriggerFright(agentTarget, self);
    }
}
// SocialActions.cs — class TrackAction
public class TrackAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        if (self == null ||
            target == null ||
            target.isDead)
        {
            self?.Visuals.Release();
            return;
        }

        float progressAmount =
            interaction.value > 0f
                ? interaction.value
                : 1f;

        target.AddSocialProgress(
            InteractionType.Track,
            progressAmount);

        Debug.Log(
            $"{self.type} tracked " +
            $"{target.type}. Progress: " +
            $"{target.GetSocialProgress(InteractionType.Track)}"
        );

        // This tracking interaction is complete.
        self.Visuals.Release();
    }
}

// SocialActions.cs — class VampireBiteAction
public class VampireBiteAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        float damage = Mathf.Max(1f, interaction.value);
        AgentDeath.HurtAgent(target, deathType.bleeding, damage);
        self.health = Mathf.Min(100f, self.health + damage * 0.5f);
        AgentFear.TryTriggerFright(target, self);
    }
}

// SocialActions.cs — class BarFightAction
public class BarFightAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        float damage = Mathf.Max(1f, interaction.value > 0f ? interaction.value : 3f);
        AgentDeath.HurtAgent(target, deathType.bleeding, damage);
    }
}

// SocialActions.cs — class HealAction
public class HealAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        target.health = Mathf.Min(100f, target.health + interaction.value);
    }
}

// SocialActions.cs — class SwoonAction
public class SwoonAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        target.waitTimer = Mathf.Max(target.waitTimer, interaction.value);
    }
}

// SocialActions.cs — class ConvertAction
public class ConvertAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        Debug.Log($"Convert attempted on {target.type}");
    }
}

// SocialActions.cs — class FleeAction
public class FleeAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        Vector3 fleeDir = (self.transform.position - target.transform.position).normalized;
        Vector3 fleeTarget = self.transform.position + fleeDir * 3f;
        AgentMovement.SetPath(self, new List<Vector3> { fleeTarget });
    }
}

// SocialActions.cs — class HarvestAnimalAction
// Moves items from the corpse's inventory onto the harvester, flagged as loot,
// up to the harvester's carry capacity. Whatever doesn't fit stays on the
// corpse, so the animal remains a valid target until it's picked clean.
public class HarvestAnimalAction : AgentTargetAction
{
    protected override void ExecuteOnAgent(Agent self, Agent target, AgentInteraction interaction)
    {
        if (self == null ||
            target == null)
        {
            self?.Visuals.Release();
            return;
        }

        if (!target.isDead)
        {
            Debug.LogWarning(
                $"{self.type} tried to harvest " +
                $"{target.type}, but it is alive."
            );

            self.Visuals.Release();
            return;
        }

        // Nothing left on the corpse, or nowhere to put it.
        if (!target.HasInventoryItems() ||
            self.FreeCarryCapacity <= 0)
        {
            self.Visuals.Release();
            return;
        }

        foreach (InventoryItem item in target.inventory)
        {
            if (item == null ||
                item.amount <= 0)
            {
                continue;
            }

            int taken = self.AddLoot(item.type, item.amount);

            if (taken <= 0)
                break; // full — nothing further will fit either

            item.amount -= taken; // remove exactly what we extracted
        }

        target.inventory.RemoveAll(
            i => i == null || i.amount <= 0);

        // Only forget the kill once it's picked clean; otherwise we come back for more.
        if (!target.HasInventoryItems() &&
            self.GetCurrentTarget(InteractionType.Track) == target)
        {
            self.ClearCurrentTarget(InteractionType.Track);
        }

        Debug.Log(
            $"{self.type} harvested {target.type} " +
            $"(carrying {self.CarriedLoot}/{self.maxCarryCapacity})."
        );

        self.Visuals.Release();
    }
}

// SocialActions.cs — class DepositResourcesAction
// ⚠️ UNCHANGED PLACEHOLDER: still the old copy-pasted harvest logic. It kills the
// target. Replace with: move self.TakeAllLoot() to wherever it's being deposited.
public class DepositResourcesAction : ISocialAction
{
    public bool Supports(TargetKind kind) => kind == TargetKind.Building;
    public void Execute(Agent self, IInteractionTarget target, AgentInteraction interaction)
    {
        if (self == null || target == null || !target.Exists || target is not Building) return;
        List<InventoryItem> loot = self.TakeAllLoot();
        foreach (InventoryItem item in loot)
        {
            if (item == null || item.amount <= 0) continue;
            switch (item.type)
            {
                case ObjectType.Food: GameManager.PlayingFood += item.amount; break;
                case ObjectType.Fur: GameManager.PlayingGold += item.amount; break;
            }
        }
        self.Visuals.Release();
    }
}
// SocialActions.cs — class SocialActions
public static class SocialActions
{
    private static readonly Dictionary<InteractionType, AgentAction> actionForInteraction = new()
    {
        { InteractionType.Combat,           AgentAction.attack },
        { InteractionType.VampireBite,      AgentAction.bite },
        { InteractionType.BarFight,         AgentAction.barFight },
        { InteractionType.HarvestAnimal,    AgentAction.harvest },
        { InteractionType.Heal,             AgentAction.heal },
        { InteractionType.Swoon,            AgentAction.swoon },
        { InteractionType.Convert,          AgentAction.convert },
        { InteractionType.Track,            AgentAction.track },
        { InteractionType.DepositResources, AgentAction.depositResources },

        // FleeFrom deliberately omitted — FleeAction just calls AgentMovement.SetPath;
        // normal movement's own walking proposal picks up the animation from there.
    };

    private static readonly Dictionary<InteractionType, int> priorityForInteraction = new()
    {
        { InteractionType.Combat,           (int)PriorityTier.Combat },
        { InteractionType.VampireBite,      (int)PriorityTier.Combat },
        { InteractionType.BarFight,         (int)PriorityTier.Combat },
        { InteractionType.HarvestAnimal,    (int)PriorityTier.Combat },
        { InteractionType.Heal,             (int)PriorityTier.Social },
        { InteractionType.Swoon,            (int)PriorityTier.Social },
        { InteractionType.Convert,          (int)PriorityTier.Social },
        { InteractionType.Track,            (int)PriorityTier.Job },
        { InteractionType.DepositResources, (int)PriorityTier.CompleteJob },
    };

    private static readonly Dictionary<InteractionType, ISocialAction> registry = new()
    {
        { InteractionType.Combat,           new CombatAction() },
        { InteractionType.VampireBite,      new VampireBiteAction() },
        { InteractionType.BarFight,         new BarFightAction() },
        { InteractionType.Heal,             new HealAction() },
        { InteractionType.Swoon,            new SwoonAction() },
        { InteractionType.Convert,          new ConvertAction() },
        { InteractionType.FleeFrom,         new FleeAction() },
        { InteractionType.HarvestAnimal,    new HarvestAnimalAction() },
        { InteractionType.Track,            new TrackAction() },
        { InteractionType.DepositResources, new DepositResourcesAction() },
    };

    public static bool TryGetAction(InteractionType type, out AgentAction action)
        => actionForInteraction.TryGetValue(type, out action);

    public static int GetPriority(InteractionType type)
        => priorityForInteraction.TryGetValue(type, out int p) ? p : (int)PriorityTier.Social;

    public static bool Supports(InteractionType type, TargetKind kind)
    {
        return registry.TryGetValue(type, out ISocialAction handler) && handler.Supports(kind);
    }

    public static void Process(Agent self, IInteractionTarget target, AgentInteraction interaction)
    {
        if (self == null || interaction == null || target == null || !target.Exists) return;
        if (!registry.TryGetValue(interaction.type, out ISocialAction handler))
        {
            Debug.LogWarning($"SocialActions: no handler registered for {interaction.type}");
            return;
        }
        if (!handler.Supports(target.Kind)) return;
        if (target is Agent agentTarget)
        {
            bool allowsDead = interaction.type == InteractionType.HarvestAnimal || ActionConditions.RequiresDeadTarget(interaction);
            if (agentTarget.isDead && !allowsDead) return;
        }
        handler.Execute(self, target, interaction);
    }
    // Hook for a future channeled/looping interaction that needs real cleanup
    // when bumped mid-effect. Nothing to do yet — current effects are instant.
    public static void Cancel(Agent self, AgentInteraction interaction)
    {
    }
}
