using UnityEngine;
public class MapLocation : IInteractionTarget
{
    public LocationType type; public Vector3 position;
    public MapLocation(LocationType type, Vector3 position) { this.type = type; this.position = position; }
    public TargetKind Kind => TargetKind.Location;
    public bool Exists => LocationRegistry.Contains(this);
    public Vector3 WorldPosition => position;
    public bool MatchesFilter(AgentInteraction interaction) => interaction != null && interaction.targetLocationTypes != null && interaction.targetLocationTypes.Contains(type);
    public bool TryGetApproach(Agent from, AgentInteraction interaction, out Vector2Int tile, out Vector3 world)
    {
        tile = Vector2Int.zero; world = position; if (from == null) return false;
        tile = AgentPathing.WorldToGrid(from, position);
        if (!AgentPathing.IsTileWalkable(from, tile)) return false;
        world = AgentPathing.GridToWorld(from, tile); return true;
    }
}
